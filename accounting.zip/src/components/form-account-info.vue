<template>
  <div class="col-6">
    <div class="form-group">
      <label for="exampleInputEmail1">確認帳戶資訊</label>
      <div class="input-group mb-3">
        <input type="text" class="form-control" />
        <div class="input-group-append">
          <span class="input-group-text"><i class="fas fa-edit"></i></span>
        </div>
      </div>
    </div>
  </div>
  <div class="row float-right">
    <div class="col">
      <button type="button" class="btn btn-block btn-default">上一步</button>
    </div>
    <div class="col">
      <button
        type="button"
        class="btn btn-default"
        data-bs-toggle="modal"
        data-bs-target="#exampleModal"
      >
        下一步
      </button>
    </div>
  </div>
</template>

<script>
export default {
    name: 'form-account-info'
}
</script>